﻿namespace TennisTournament.Application;

public class Class1
{

}
