﻿namespace TennisTournament.Domain;

public class Class1
{

}
