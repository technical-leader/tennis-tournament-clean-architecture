﻿namespace TennisTournament.Infrastructure;

public class Class1
{

}
