﻿namespace TennisTournament.Tests.Integration;

public class UnitTest1
{
    [Fact]
    public void Test1()
    {

    }
}
